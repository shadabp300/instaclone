const Button = () => {
    return (
        <button >Enter</button>
    );
}
export default Button;